using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class MainMenu : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    } 
    public void QuitGame()
    {
        Debug.Log("QUIT");
        Application.Quit();
    }
    public void PlayAgain()
    {
        SceneManager.LoadScene("Menu");
    }
    public void BackButton()
    {
        SceneManager.LoadScene("Menu");
    }
    public void NextButtonNinja()
    {
        SceneManager.LoadScene("SampleScene");
    }
    public void NextButtonHex()
    {
        SceneManager.LoadScene("Hidden Game");

    }
    public void HiddenInstruction()
    {
        SceneManager.LoadScene("SpinningGame");

    }
}
