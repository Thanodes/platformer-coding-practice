using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController2D controller;
    public Animator animator;

    float horizontalMove = 0f;
    public float runSpeed = 0f;
    bool jump = false;
    bool crouch = false;
    // Start is called before the first frame update
    void Start()
    {

    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Coins"))
        {
            Destroy(other.gameObject);
        }
  
        if (other.gameObject.CompareTag("EndPortal"))
        {
           SceneManager.LoadScene("Ending");
        }
    }
    // Update is called once per frame
    void Update()
    {
        // this detects input for a,d keys or left and right from controller and assigns it to -1 or 1 depending on the direction you are going.
        horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;  // horizontal relays left and right movement due to input manager

        animator.SetFloat("speed", Mathf.Abs(horizontalMove));
       
        
        if (Input.GetButtonDown("Jump"))
        { //relays vertical input due to input manager
            jump = true;
           animator.SetBool("IsJumping", true);
           
        }

        if (Input.GetButtonDown("Crouch"))
        {
            crouch = true;
        }
        else if (Input.GetButtonUp("Crouch"))
        {
            crouch = false;
        }
    }
    public void OnLanding()
    {
        animator.SetBool("IsJumping", false);
    }
    public void OnCrouching()
    {
        animator.SetBool("IsCrouching", false);
    }
    void FixedUpdate()
    {
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);  // moves character and makes the movement consistent
        jump = false;

    }
}
